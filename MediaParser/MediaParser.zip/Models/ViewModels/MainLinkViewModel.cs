﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace MediaParser.Models.ViewModels
{
    public class MainLinkViewModel
    {
        [Display(Name = "Ссылка на видео")]
        [Required(ErrorMessage = "Вам необходимо вставить ссылку")]
        [Url(ErrorMessage = "Указан некорректный URL")]
        public string Link { get; set; }
        public BusinessLogic.Types.InfoUnit InfoUnit { get; set; }
    }
}